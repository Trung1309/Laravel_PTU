$('.slider').slick({
    infinite: true,
    slidesToShow: 5,
    slidesToScroll: 1,
    prevArrow: '<button type="button" class="slick-prev"><i class="fa-solid fa-chevron-left" style="color: #ffffff;"></i></button>',
    nextArrow: '<button type="button" class="slick-next"><i class="fa-solid fa-chevron-right" style="color: #ffffff;"></i></button>',
    autoplaySpeed:3000
  });